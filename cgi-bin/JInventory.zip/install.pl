#!/usr/bin/perl

#This is the install script for the JInventory system.  Just run and enter the required information...


#INTRODUCTION
print "
Welcome to the JInventory Installation program 
         [written by: Jason St-Cyr {jstcyr\@ottawa.com}]
########################################################################
\n
Please follow the instructions carefully.  
The system will set itself up nicely if you properly complete all of the 
information required.
\n\nWould you like to install the JInventory system at this time? (y/n) > ";

$_=<STDIN>;
chomp;
tr/[a-z]/[A-Z]/;

if( ($input ne "Y")||($input ne "YES")){print "Good bye!\n"; exit;}

#GET SERVER URL
print "
       \nEnter the url for your web server you wish the JInventory system to run from:
       \n[Default: https://www.scs.carleton.ca]
       \n> ";

chomp($input=<STDIN>);
if($input eq ""){$url="https://www.scs.carleton.ca";}
else{$url="$input";}


#GET HTML DIRECTORY
print "
       \nEnter your htdocs directory.
       \n[Default:/home/httpd/html]
       \n> ";
chomp($input=<STDIN>);

if($input eq ""){$web_dir="home/httpd/html";}
else{$web_dir="$input";}

#Create directories and move files
unless (-e "$web_dir/inventory"){print "\nCreating directory $webdir/inventory";`mkdir $web_dir/inventory`;}
print "\nInstalling index.html file";
`cp -i index.html $web_dir/inventory`;
print "\nInstalling computerchip.gif logo";
`cp -i computerchip.gif $web_dir/inventory`;


#GET CGI-BIN LOCATION
print "
       \nEnter the directory to install the database script to (this should be your cgi-bin directory)
       \n[Default:/home/httpd/cgi-bin]
       \n> ";

chomp($input=<STDIN>);

if($input eq ""){$cgibin_dir="/home/httpd/cgi-bin/";}
else{$cgibin_dir="$input";}

#Move cgi-lib.pl and inventory.pl to cgi-bin directory
print "\nInstalling library file cgi-lib.pl";
`cp-i cgi-lib.pl $cgibin_path`;
print "\nInstalling JInventory script inventory.pl";
`cp -i inventory.pl $cgibin_path`;

#BEGIN CREATING INVENTORY DIRECTORIES
$database_dir="$cgi-bin_dir/../inventorydb";
unless (-e "$database_dir"){print "\nCreating database directory $database_dir"; `mkdir $database_dir`;}
unless (-e "$database_dir/conf/"){print "\nCreating configuration directory $database_dir/conf"; `mkdir $database_dir/conf`;}

#Move configure files to conf directory
print "\nCopying configuration files:";
print "\nlocations.txt";
`cp -i locations.txt $database_dir/conf`;
print "\nstatus.txt";
`cp -i status.txt $database_dir/conf`;
print "\nstatus_description.txt";
`cp -i status_description.txt $database_dir/conf`;
print "\ntypes.txt";
`cp -i types.txt $database_dir/conf`;
print "\nos.txt";
`cp -i os.txt $database_dir/conf`;


print "
       \nthe JInventory system has been installed!  To access the directory, go to: \"$url/inventory/index.html\"";
